import React from 'react';
const MyComponent = () => {
    return <div>
              <p>This is my first Stateless Functional Component.</p>
           </div>;
    }
    export default MyComponent;