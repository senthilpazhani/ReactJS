import React from 'react';
class ChildComponent extends React.Component {
    render() {
       return (
          <div>
             <h2>External and Reusable Child Component</h2>
             <p>Content of External Child Component</p>
          </div>
       );
    }
  }
  export default ChildComponent;